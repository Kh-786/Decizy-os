BEGIN;
SELECT plan(16);

SELECT has_table('public', 'profiles', 'profiles table exists');
SELECT has_table('public', 'projects', 'projects table exists');
SELECT has_table('public', 'project_members', 'project_members table exists');
SELECT has_table('public', 'a0_assessments', 'A0 assessments table exists');
SELECT has_table('public', 'project_decisions', 'project decisions table exists');
SELECT has_table('public', 'decision_revisions', 'decision revisions table exists');
SELECT has_table('public', 'project_documents', 'project documents table exists');
SELECT has_table('public', 'audit_logs', 'audit logs table exists');

SELECT ok((SELECT relrowsecurity FROM pg_class WHERE oid = 'public.profiles'::regclass), 'RLS enabled on profiles');
SELECT ok((SELECT relrowsecurity FROM pg_class WHERE oid = 'public.projects'::regclass), 'RLS enabled on projects');
SELECT ok((SELECT relrowsecurity FROM pg_class WHERE oid = 'public.project_members'::regclass), 'RLS enabled on project_members');
SELECT ok((SELECT relrowsecurity FROM pg_class WHERE oid = 'public.project_decisions'::regclass), 'RLS enabled on project_decisions');
SELECT ok((SELECT relrowsecurity FROM pg_class WHERE oid = 'public.audit_logs'::regclass), 'RLS enabled on audit_logs');

SELECT ok(EXISTS (
  SELECT 1 FROM pg_policies
  WHERE schemaname = 'public' AND tablename = 'audit_logs'
    AND policyname = 'Authorized users can view audit logs'
    AND cmd = 'SELECT'
), 'explicit hardened audit-log SELECT policy exists');
SELECT ok(NOT has_table_privilege('anon', 'public.audit_logs', 'SELECT'), 'anon cannot SELECT audit logs');
SELECT ok(NOT has_table_privilege('anon', 'public.audit_logs', 'INSERT'), 'anon cannot INSERT audit logs');

SELECT * FROM finish();
ROLLBACK;
