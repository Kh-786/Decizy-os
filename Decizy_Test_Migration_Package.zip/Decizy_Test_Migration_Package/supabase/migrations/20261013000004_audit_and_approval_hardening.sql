-- Decizy corrective migration 20261013000004
-- Purpose: close global audit-log visibility and make approval attribution authoritative.
-- Target: decizy-test only until validated. Do NOT apply to production automatically.
-- Review note: this migration intentionally disables administrator proxy-approval.
-- Admin approvals are attributed to the authenticated admin; project stakeholder signoff
-- must be performed by that stakeholder's authenticated account.

BEGIN;

-- 1) Global audit rows (project_id IS NULL) are visible to admins only.
-- Project-scoped rows are visible only to users who can access that project.
DROP POLICY IF EXISTS "Project members can view audit logs" ON public.audit_logs;
CREATE POLICY "Authorized users can view audit logs"
  ON public.audit_logs
  FOR SELECT
  TO authenticated
  USING (
    public.is_admin()
    OR (
      project_id IS NOT NULL
      AND public.can_access_project(project_id)
    )
  );

-- Keep audit logs append-only for ordinary authenticated users.
REVOKE UPDATE, DELETE, TRUNCATE ON public.audit_logs FROM anon, authenticated;
REVOKE ALL ON public.audit_logs FROM anon;
GRANT SELECT, INSERT ON public.audit_logs TO authenticated;

-- 2) Rebind approval validation so a caller can never attribute an approval to another user.
-- Administrators retain operational access, but approval attribution is always the caller.
CREATE OR REPLACE FUNCTION public.validate_decision_state_and_approvals()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
DECLARE
  v_is_authorized_signatory BOOLEAN := FALSE;
BEGIN
  -- Prevent changing the decision's project or decision-type identity.
  IF TG_OP = 'UPDATE' THEN
    IF NEW.project_id IS DISTINCT FROM OLD.project_id THEN
      RAISE EXCEPTION 'Security violation: Decision project_id cannot be changed.';
    END IF;
    IF NEW.type_code IS DISTINCT FROM OLD.type_code THEN
      RAISE EXCEPTION 'Security violation: Decision type_code cannot be changed.';
    END IF;
  END IF;

  -- Non-admin callers must be project stakeholders.
  IF NOT public.is_admin() THEN
    SELECT
      EXISTS (
        SELECT 1
        FROM public.projects p
        WHERE p.id = NEW.project_id
          AND (
            p.customer_id = auth.uid()
            OR p.project_manager_id = auth.uid()
            OR p.designer_id = auth.uid()
          )
      )
      OR EXISTS (
        SELECT 1
        FROM public.project_members pm
        WHERE pm.project_id = NEW.project_id
          AND pm.user_id = auth.uid()
          AND pm.role IN ('customer', 'project_manager', 'designer')
      )
    INTO v_is_authorized_signatory;

    IF NOT v_is_authorized_signatory THEN
      RAISE EXCEPTION 'Security violation: Caller is not an authorized team member of this project.';
    END IF;
  END IF;

  IF TG_OP = 'INSERT' THEN
    IF NEW.status = 'Approved' AND NOT public.is_admin() THEN
      RAISE EXCEPTION 'Security violation: Decisions cannot be inserted as Approved; use the formal approval transition.';
    END IF;

    IF NEW.status = 'Approved' THEN
      NEW.approved_by := auth.uid();
      NEW.approved_at := NOW();
    ELSE
      NEW.approved_by := NULL;
      NEW.approved_at := NULL;
    END IF;

    NEW.created_at := NOW();
    NEW.updated_at := NOW();
    RETURN NEW;
  END IF;

  -- UPDATE: the first transition to Approved stamps caller/time.
  IF NEW.status = 'Approved' THEN
    IF OLD.status IS DISTINCT FROM 'Approved' THEN
      NEW.approved_by := auth.uid();
      NEW.approved_at := NOW();
    ELSE
      -- Approved records retain immutable historical attribution.
      IF NEW.approved_by IS DISTINCT FROM OLD.approved_by THEN
        RAISE EXCEPTION 'Security violation: Cannot modify approved_by on an already approved decision.';
      END IF;
      IF NEW.approved_at IS DISTINCT FROM OLD.approved_at THEN
        RAISE EXCEPTION 'Security violation: Cannot modify approved_at on an already approved decision.';
      END IF;
      NEW.approved_by := OLD.approved_by;
      NEW.approved_at := OLD.approved_at;
    END IF;
  ELSE
    -- A decision leaving Approved has no current approval attribution.
    NEW.approved_by := NULL;
    NEW.approved_at := NULL;
  END IF;

  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_decision_state_and_approvals
  ON public.project_decisions;
CREATE TRIGGER trg_validate_decision_state_and_approvals
  BEFORE INSERT OR UPDATE ON public.project_decisions
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_decision_state_and_approvals();

COMMIT;
