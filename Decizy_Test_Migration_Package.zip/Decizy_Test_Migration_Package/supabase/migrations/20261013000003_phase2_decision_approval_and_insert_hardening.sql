
-- 1. HARDENED DECISION VALIDATION FUNCTION (INSERT + UPDATE)
CREATE OR REPLACE FUNCTION public.validate_decision_state_and_approvals()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql AS $$
DECLARE
  v_is_authorized_signatory BOOLEAN := FALSE;
BEGIN
  -- ----------------------------------------------------------------------------
  -- BRANCH A: PLATFORM ADMINISTRATORS
  -- ----------------------------------------------------------------------------
  IF public.is_admin() THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status = 'Approved' THEN
        -- If admin specifies an approved_by other than themselves, it MUST be a verified project stakeholder
        IF NEW.approved_by IS NOT NULL AND NEW.approved_by != auth.uid() THEN
          IF NOT EXISTS (
            SELECT 1 FROM public.projects p
            WHERE p.id = NEW.project_id AND (
              p.customer_id = NEW.approved_by OR
              p.project_manager_id = NEW.approved_by OR
              p.designer_id = NEW.approved_by
            )
          ) AND NOT EXISTS (
            SELECT 1 FROM public.project_members pm
            WHERE pm.project_id = NEW.project_id AND pm.user_id = NEW.approved_by
          ) THEN
            RAISE EXCEPTION 'Security violation: Administrator proxy approval must reference an authorized project stakeholder.';
          END IF;
        ELSE
          NEW.approved_by := auth.uid();
        END IF;
        NEW.approved_at := NOW();
      ELSE
        -- Non-approved inserts must not carry approval metadata
        NEW.approved_by := NULL;
        NEW.approved_at := NULL;
      END IF;
      NEW.created_at := NOW();
      NEW.updated_at := NOW();
      RETURN NEW;

    ELSIF TG_OP = 'UPDATE' THEN
      -- Prevent primary/foreign key modification
      IF NEW.project_id IS DISTINCT FROM OLD.project_id THEN
        RAISE EXCEPTION 'Security violation: Decision project_id cannot be changed.';
      END IF;
      IF NEW.type_code IS DISTINCT FROM OLD.type_code THEN
        RAISE EXCEPTION 'Security violation: Decision type_code cannot be changed.';
      END IF;

      IF NEW.status = 'Approved' THEN
        IF OLD.status IS DISTINCT FROM 'Approved' THEN
          -- First-time approval by admin
          IF NEW.approved_by IS NOT NULL AND NEW.approved_by != auth.uid() THEN
            IF NOT EXISTS (
              SELECT 1 FROM public.projects p
              WHERE p.id = NEW.project_id AND (
                p.customer_id = NEW.approved_by OR
                p.project_manager_id = NEW.approved_by OR
                p.designer_id = NEW.approved_by
              )
            ) AND NOT EXISTS (
              SELECT 1 FROM public.project_members pm
              WHERE pm.project_id = NEW.project_id AND pm.user_id = NEW.approved_by
            ) THEN
              RAISE EXCEPTION 'Security violation: Administrator proxy approval must reference an authorized project stakeholder.';
            END IF;
          ELSE
            NEW.approved_by := auth.uid();
          END IF;
          NEW.approved_at := NOW();
        ELSE
          -- Modifying an already-approved decision: historical attribution is strictly locked
          IF NEW.approved_by IS DISTINCT FROM OLD.approved_by THEN
            RAISE EXCEPTION 'Security violation: Cannot modify approved_by on an already approved decision.';
          END IF;
          IF NEW.approved_at IS DISTINCT FROM OLD.approved_at THEN
            RAISE EXCEPTION 'Security violation: Cannot modify approved_at on an already approved decision.';
          END IF;
          NEW.approved_by := OLD.approved_by;
          NEW.approved_at := OLD.approved_at;
        END IF;
      ELSE
        -- Any transition away from Approved (or non-approved update) clears approval attribution
        NEW.approved_by := NULL;
        NEW.approved_at := NULL;
      END IF;

      NEW.updated_at := NOW();
      RETURN NEW;
    END IF;
  END IF;

  -- ----------------------------------------------------------------------------
  -- BRANCH B: STANDARD PROJECT STAKEHOLDERS (Customer, Designer, Project Manager)
  -- ----------------------------------------------------------------------------
  -- Verify caller is an authorized stakeholder of the referenced project
  SELECT EXISTS (
    SELECT 1 FROM public.projects p
    WHERE p.id = NEW.project_id AND (
      p.customer_id = auth.uid() OR
      p.project_manager_id = auth.uid() OR
      p.designer_id = auth.uid()
    )
  ) OR EXISTS (
    SELECT 1 FROM public.project_members pm
    WHERE pm.project_id = NEW.project_id 
      AND pm.user_id = auth.uid() 
      AND pm.role IN ('customer', 'project_manager', 'designer')
  ) INTO v_is_authorized_signatory;

  IF NOT v_is_authorized_signatory THEN
    RAISE EXCEPTION 'Security violation: Caller is not an authorized team member of this project.';
  END IF;

  -- B.1 INSERT RULES
  IF TG_OP = 'INSERT' THEN
    -- Non-admins cannot insert decisions directly as 'Approved'
    IF NEW.status = 'Approved' THEN
      RAISE EXCEPTION 'Security violation: Decisions cannot be directly inserted with Approved status. A formal review and signoff transition is required.';
    END IF;

    -- Strip any caller-supplied approval attribution on initial insert
    NEW.approved_by := NULL;
    NEW.approved_at := NULL;
    NEW.created_at := NOW();
    NEW.updated_at := NOW();
    RETURN NEW;

  -- B.2 UPDATE RULES
  ELSIF TG_OP = 'UPDATE' THEN
    -- Prevent structural key modification
    IF NEW.project_id IS DISTINCT FROM OLD.project_id THEN
      RAISE EXCEPTION 'Security violation: Decision project_id cannot be changed.';
    END IF;
    IF NEW.type_code IS DISTINCT FROM OLD.type_code THEN
      RAISE EXCEPTION 'Security violation: Decision type_code cannot be changed.';
    END IF;

    IF NEW.status = 'Approved' THEN
      IF OLD.status IS DISTINCT FROM 'Approved' THEN
        -- Path 1: First-time approval
        -- Authenticated caller ID and current timestamp are stamped authoritatively
        NEW.approved_by := auth.uid();
        NEW.approved_at := NOW();
      ELSE
        -- Path 2: Modifying an already-approved decision
        -- Prevent tampering with historical signer or signoff timestamp
        IF NEW.approved_by IS DISTINCT FROM OLD.approved_by THEN
          RAISE EXCEPTION 'Security violation: Cannot modify approved_by on an already approved decision.';
        END IF;
        IF NEW.approved_at IS DISTINCT FROM OLD.approved_at THEN
          RAISE EXCEPTION 'Security violation: Cannot modify approved_at on an already approved decision.';
        END IF;
        NEW.approved_by := OLD.approved_by;
        NEW.approved_at := OLD.approved_at;
      END IF;
    ELSE
      -- Path 3 & 4: Status is NOT 'Approved'
      -- When transitioning away from Approved, or updating a Draft/Review decision:
      NEW.approved_by := NULL;
      NEW.approved_at := NULL;
    END IF;

    NEW.updated_at := NOW();
    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- 2. REBIND TRIGGER TO BEFORE INSERT OR UPDATE
DROP TRIGGER IF EXISTS trg_validate_decision_state_and_approvals ON public.project_decisions;
CREATE TRIGGER trg_validate_decision_state_and_approvals
  BEFORE INSERT OR UPDATE ON public.project_decisions
  FOR EACH ROW EXECUTE FUNCTION public.validate_decision_state_and_approvals();
