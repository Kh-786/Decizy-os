#!/usr/bin/env python3
"""Fast fail-closed checks before local Supabase executes migrations.

This is a guardrail, not a SQL parser or substitute for database/RLS tests.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / "supabase" / "migrations"
EXPECTED = [
    "20261013000000_initial_decizy_schema.sql",
    "20261013000001_phase2_security_and_memberships.sql",
    "20261013000002_phase2_security_hardening.sql",
    "20261013000003_phase2_decision_approval_and_insert_hardening.sql",
    "20261013000004_audit_and_approval_hardening.sql",
]

def fail(message: str) -> None:
    print(f"FAIL: {message}")
    sys.exit(1)

files = sorted(p.name for p in MIGRATIONS.glob("*.sql"))
if files != EXPECTED:
    fail(f"Migration list/order mismatch. Expected {EXPECTED}; found {files}")

for name in files:
    content = (MIGRATIONS / name).read_text(encoding="utf-8")
    if not re.match(r"^\d{14}_[a-z0-9_]+\.sql$", name):
        fail(f"Invalid migration filename: {name}")
    if not content.strip():
        fail(f"Empty migration: {name}")
# Fail closed on high-risk destructive statements until manually reviewed.
# This intentionally checks uncommented lines only and is not a complete SQL parser.
for name in files:
    lines = (MIGRATIONS / name).read_text(encoding="utf-8").splitlines()
    for line_no, line in enumerate(lines, 1):
        code = line.split("--", 1)[0]
        if re.search(r"\bDROP\s+(DATABASE|SCHEMA)\b", code, re.I):
            fail(f"Forbidden destructive statement in {name}:{line_no}")

# Contract checks: critical tables and controls must remain represented in source.
all_sql = "\n".join((MIGRATIONS / name).read_text(encoding="utf-8") for name in files)
for table in ["profiles", "projects", "project_members", "a0_assessments", "project_decisions", "decision_revisions", "project_documents", "audit_logs"]:
    if not re.search(rf"\bpublic\.{table}\b", all_sql, re.I):
        fail(f"Required table reference missing: public.{table}")
for fragment in ["ENABLE ROW LEVEL SECURITY", "validate_decision_state_and_approvals", "Authorized users can view audit logs"]:
    if fragment.lower() not in all_sql.lower():
        fail(f"Required security control missing: {fragment}")

print(f"PASS: {len(files)} ordered migrations, required schema/security markers, and basic destructive-operation guardrails.")
print("NOTE: Database execution, SQL lint, and RLS behavior are validated by separate CI steps; this static check alone is not proof of security.")
