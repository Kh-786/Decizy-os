# Decizy test-only migration package

**Target: `decizy-test` only** (`hfiqvixhqgnbgfmwsnlr`). Do not apply to the original production project (`cqfxcgtcfcujluzxokii`) or the live AnyRoomz/Selldone site.

## Contents and order
1. `20261013000000_initial_decizy_schema.sql`
2. `20261013000001_phase2_security_and_memberships.sql`
3. `20261013000002_phase2_security_hardening.sql`
4. `20261013000003_phase2_decision_approval_and_insert_hardening.sql`
5. `20261013000004_audit_and_approval_hardening.sql` (proposed corrective migration; review before use)

The first four files are extracted from the user's supplied `sandbox_test.sql` harness, from sections explicitly labeled as the original application migrations. They are not generated from a live repository checkout, because the GitHub connector could not access the reported repository. Review against the canonical repository before deployment if it becomes accessible.

## Critical status
- No migration has been successfully executed against either Supabase project.
- The original Decizy project is production-labeled and has no public tables or recorded migrations at the time of inspection. No backup was visible.
- Do not use the original production project as a test environment.
- The supplied harness wraps its setup/tests in a transaction and ends with `ROLLBACK`; it is not an installation script. Do not execute the harness as the migration sequence.
- Run each migration file separately and in order on `decizy-test`, capturing the result of each. Stop at the first error.
- Before migration 00004, review its policy/function assumptions and test approval behavior. This version intentionally removes administrator proxy-approval.

## Verification required
The supplied owner-level harness can test triggers and constraints, but owner-level execution bypasses ordinary RLS. After migrations, verify with distinct authenticated sessions that global audit rows are admin-only, project audit rows require membership/access, anon cannot read/write audit logs, and approval attribution cannot be spoofed. Also test normal project creation, decisions, revisions, memberships, and A0 assessment submission.

## Automated validation pipeline added
This package now includes a starter CI pipeline:
- `.github/workflows/decizy-database-ci.yml` runs on pull requests and pushes to `main` when database files change.
- `scripts/validate_migrations.py` checks migration names/order, required schema/security markers, and a small set of high-risk destructive SQL patterns.
- `supabase/tests/database/guardrails.test.sql` checks required tables, RLS-enabled flags, the hardened audit-log policy, and anon audit-log privileges.
- `supabase/config.toml` configures an isolated local Supabase stack for CI.

The intended CI sequence is: static guardrails -> start local Supabase -> reset from migrations -> SQL lint -> pgTAP assertions. A failed stage blocks the pipeline. CI does not deploy to hosted production and does not auto-edit SQL. It supplies a reliable failure report; a correction must be committed and all checks rerun.

## Important limits and current status
- Static guardrail validation was run locally and passed for all five migration files.
- The local Supabase stack, `supabase db reset`, SQL lint, and pgTAP tests have **not** been run in this environment, so no database execution pass is claimed.
- Migration 00004 remains a proposed security correction and must be validated against the local Supabase stack before use.
- The GitHub connector could not see `Kh-786/Decizy-os` (repository listing/search returned no results). Therefore this workflow has **not** been committed to the live source repository and is not yet running automatically. Import these files into the repository before expecting CI to run.
- This pipeline intentionally has no hosted-production deployment step. Production release should be a separate, protected workflow after test CI passes and a verified backup/rollback plan exists.
